import { defineField, defineType } from 'sanity';

export default defineType({
  name: 'siteSettings',
  title: 'Site Settings',
  type: 'document',
  // Lock to a single document — there's only ever one site config
  __experimental_omnisearch_visibility: false,
  fields: [
    defineField({
      name: 'siteName',
      title: 'Site Name',
      type: 'string',
      initialValue: 'Cinegma Films',
      validation: (R) => R.required(),
    }),
    defineField({
      name: 'tagline',
      title: 'Tagline',
      type: 'string',
      initialValue: 'Independent Pakistani cinema',
    }),
    defineField({
      name: 'description',
      title: 'Site Description (SEO)',
      type: 'text',
      rows: 3,
      validation: (R) => R.required().max(300),
    }),
    defineField({
      name: 'logo',
      title: 'Logo (SVG or PNG, square)',
      type: 'image',
      options: { hotspot: false },
    }),
    defineField({
      name: 'ogDefault',
      title: 'Default Open Graph Image (1200×630)',
      type: 'image',
      options: { hotspot: true },
    }),
    defineField({
      name: 'contactEmail',
      title: 'Contact Email',
      type: 'string',
      initialValue: 'info@cinegmafilms.com',
      validation: (R) => R.required().email(),
    }),
    defineField({
      name: 'contactPhone',
      title: 'Contact Phone',
      type: 'string',
    }),
    defineField({
      name: 'socials',
      title: 'Social Links',
      type: 'array',
      of: [
        {
          type: 'object',
          fields: [
            { name: 'platform', type: 'string', title: 'Platform' },
            { name: 'url', type: 'url', title: 'URL' },
          ],
          preview: { select: { title: 'platform', subtitle: 'url' } },
        },
      ],
    }),
    defineField({
      name: 'awardsCount',
      title: 'Total Awards',
      type: 'number',
      initialValue: 14,
    }),
    defineField({
      name: 'selectionsCount',
      title: 'Total Festival Selections',
      type: 'number',
      initialValue: 22,
    }),
    defineField({
      name: 'countriesCount',
      title: 'Countries',
      type: 'number',
      initialValue: 9,
    }),
  ],
  preview: {
    prepare: () => ({ title: 'Site Settings' }),
  },
});
