import { defineField, defineType } from 'sanity';

export default defineType({
  name: 'award',
  title: 'Award',
  type: 'document',
  fields: [
    defineField({ name: 'festival', title: 'Festival', type: 'string', validation: (R) => R.required() }),
    defineField({ name: 'prize',    title: 'Prize',    type: 'string', validation: (R) => R.required() }),
    defineField({ name: 'year',     title: 'Year',     type: 'number', validation: (R) => R.required() }),
    defineField({ name: 'country',  title: 'Country',  type: 'string' }),
    defineField({
      name: 'film',
      title: 'Film',
      type: 'reference',
      to: [{ type: 'film' }],
    }),
  ],
  preview: {
    select: { title: 'prize', subtitle: 'festival', year: 'year' },
    prepare: ({ title, subtitle, year }) => ({
      title: `${title}`,
      subtitle: `${subtitle} · ${year}`,
    }),
  },
  orderings: [
    { name: 'year', title: 'Most recent', by: [{ field: 'year', direction: 'desc' }] },
  ],
});
