import { defineField, defineType } from 'sanity';

export default defineType({
  name: 'pressItem',
  title: 'Press Item',
  type: 'document',
  fields: [
    defineField({ name: 'headline',   title: 'Headline',  type: 'string', validation: (R) => R.required() }),
    defineField({ name: 'outlet',     title: 'Outlet',    type: 'string', validation: (R) => R.required() }),
    defineField({ name: 'publishedAt',title: 'Published', type: 'datetime', validation: (R) => R.required() }),
    defineField({ name: 'url',        title: 'URL',       type: 'url', validation: (R) => R.required() }),
    defineField({ name: 'excerpt',    title: 'Excerpt',   type: 'text', rows: 3 }),
    defineField({ name: 'outletLogo', title: 'Outlet Logo', type: 'image' }),
  ],
  preview: {
    select: { title: 'headline', subtitle: 'outlet', media: 'outletLogo' },
  },
  orderings: [
    { name: 'recent', title: 'Most recent', by: [{ field: 'publishedAt', direction: 'desc' }] },
  ],
});
