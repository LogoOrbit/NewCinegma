import { defineField, defineType } from 'sanity';

export default defineType({
  name: 'service',
  title: 'Service',
  type: 'document',
  fields: [
    defineField({ name: 'title',   title: 'Title',   type: 'string', validation: (R) => R.required() }),
    defineField({ name: 'summary', title: 'Summary', type: 'text', rows: 3 }),
    defineField({
      name: 'deliverables',
      title: 'Deliverables',
      type: 'array',
      of: [{ type: 'string' }],
      options: { layout: 'tags' },
    }),
    defineField({ name: 'startingPrice', title: 'Starting Price (optional)', type: 'string' }),
    defineField({ name: 'order', title: 'Sort Order', type: 'number', initialValue: 100 }),
  ],
  preview: { select: { title: 'title', subtitle: 'summary' } },
  orderings: [
    { name: 'order', title: 'Sort order', by: [{ field: 'order', direction: 'asc' }] },
  ],
});
