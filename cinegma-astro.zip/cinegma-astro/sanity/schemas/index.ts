import siteSettings from './siteSettings';
import film from './film';
import award from './award';
import pressItem from './pressItem';
import service from './service';
import teamMember from './teamMember';

export const schemaTypes = [
  siteSettings,
  film,
  award,
  pressItem,
  service,
  teamMember,
];
