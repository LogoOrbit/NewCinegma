import { defineField, defineType } from 'sanity';

export default defineType({
  name: 'film',
  title: 'Film',
  type: 'document',
  groups: [
    { name: 'core', title: 'Core', default: true },
    { name: 'media', title: 'Media' },
    { name: 'access', title: 'Access' },
    { name: 'crew', title: 'Crew & Awards' },
    { name: 'press', title: 'Press' },
    { name: 'meta', title: 'Meta' },
  ],
  fields: [
    defineField({ name: 'title',    title: 'Title',    type: 'string', group: 'core', validation: (R) => R.required() }),
    defineField({ name: 'slug',     title: 'Slug',     type: 'slug',   group: 'core', options: { source: 'title', maxLength: 96 }, validation: (R) => R.required() }),
    defineField({ name: 'tagline',  title: 'Tagline',  type: 'string', group: 'core', description: 'e.g. "Tussle"' }),
    defineField({ name: 'synopsis', title: 'Synopsis', type: 'text', group: 'core', rows: 4 }),
    defineField({ name: 'directorsNote', title: "Director's Note", type: 'text', group: 'core', rows: 6 }),

    defineField({ name: 'releaseYear', title: 'Release Year', type: 'number', group: 'core' }),
    defineField({ name: 'runtime',     title: 'Runtime', type: 'string', group: 'core', description: 'e.g. "23 min"' }),
    defineField({
      name: 'genre',
      title: 'Genre',
      type: 'array',
      group: 'core',
      of: [{ type: 'string' }],
      options: {
        list: ['Thriller', 'Drama', 'Documentary', 'War Drama', 'Psychological Thriller', 'Family', 'Romance', 'Horror', 'Comedy'],
      },
    }),
    defineField({ name: 'language', title: 'Language', type: 'string', group: 'core', options: { list: ['Urdu', 'English', 'Sindhi', 'Punjabi'] } }),
    defineField({ name: 'director', title: 'Director', type: 'string', group: 'core', initialValue: 'Syed Asad Raza Abidi' }),

    /* MEDIA */
    defineField({ name: 'poster',     title: 'Poster (vertical or 16:9)', type: 'image', group: 'media', options: { hotspot: true } }),
    defineField({ name: 'still',      title: 'Hero Still', type: 'image', group: 'media', options: { hotspot: true } }),
    defineField({ name: 'thumbVideo', title: 'Thumbnail Video (silent loop, MP4)', type: 'file', group: 'media', options: { accept: 'video/mp4' } }),
    defineField({
      name: 'stills',
      title: 'Production Stills',
      type: 'array',
      group: 'media',
      of: [{ type: 'image', options: { hotspot: true } }],
    }),

    /* ACCESS */
    defineField({
      name: 'access',
      title: 'Access',
      type: 'string',
      group: 'access',
      options: {
        list: [
          { title: 'Free — public stream', value: 'free' },
          { title: 'Screener — password protected', value: 'screener' },
          { title: 'Unreleased — coming soon', value: 'unreleased' },
        ],
        layout: 'radio',
      },
      initialValue: 'unreleased',
      validation: (R) => R.required(),
    }),
    defineField({ name: 'trailerUrl',  title: 'Trailer URL',  type: 'url', group: 'access' }),
    defineField({ name: 'screenerUrl', title: 'Screener URL', type: 'url', group: 'access', description: 'Full film URL (only shown if access = free)' }),

    /* CREW + AWARDS */
    defineField({
      name: 'crew',
      title: 'Crew',
      type: 'array',
      group: 'crew',
      of: [{
        type: 'object',
        fields: [
          { name: 'role', type: 'string', title: 'Role' },
          { name: 'name', type: 'string', title: 'Name' },
        ],
        preview: { select: { title: 'name', subtitle: 'role' } },
      }],
    }),
    defineField({
      name: 'awards',
      title: 'Awards Won',
      type: 'array',
      group: 'crew',
      of: [{
        type: 'object',
        fields: [
          { name: 'festival', type: 'string', title: 'Festival' },
          { name: 'prize',    type: 'string', title: 'Prize' },
          { name: 'year',     type: 'number', title: 'Year' },
          { name: 'country',  type: 'string', title: 'Country' },
        ],
        preview: { select: { title: 'prize', subtitle: 'festival' } },
      }],
    }),
    defineField({
      name: 'festivals',
      title: 'Festival Selections',
      type: 'array',
      group: 'crew',
      of: [{
        type: 'object',
        fields: [
          { name: 'name',      type: 'string', title: 'Festival Name' },
          { name: 'year',      type: 'number', title: 'Year' },
          { name: 'country',   type: 'string', title: 'Country' },
          { name: 'selection', type: 'string', title: 'Selection Type', options: { list: ['Official Selection', 'Competition', 'Out of Competition'] } },
        ],
        preview: { select: { title: 'name', subtitle: 'year' } },
      }],
    }),
    defineField({ name: 'awardsCount', title: 'Awards Count (override)', type: 'number', group: 'crew' }),

    /* PRESS */
    defineField({
      name: 'pressQuotes',
      title: 'Press Quotes',
      type: 'array',
      group: 'press',
      of: [{
        type: 'object',
        fields: [
          { name: 'quote',  type: 'text', title: 'Quote', rows: 3 },
          { name: 'source', type: 'string', title: 'Source (Outlet)' },
        ],
        preview: { select: { title: 'source', subtitle: 'quote' } },
      }],
    }),

    /* META */
    defineField({ name: 'featured', title: 'Featured on homepage', type: 'boolean', group: 'meta', initialValue: false }),
    defineField({ name: 'order',    title: 'Sort Order', type: 'number', group: 'meta', initialValue: 100 }),
  ],
  preview: {
    select: { title: 'title', subtitle: 'tagline', media: 'poster' },
  },
  orderings: [
    { name: 'order',  title: 'Sort order',    by: [{ field: 'order', direction: 'asc' }] },
    { name: 'recent', title: 'Newest first',  by: [{ field: 'releaseYear', direction: 'desc' }] },
  ],
});
