import groq from 'groq';

/* ────────────────  FILMS  ──────────────── */

export const allFilmsQuery = groq`
  *[_type == "film"] | order(order asc, releaseYear desc) {
    _id,
    title,
    "slug": slug.current,
    tagline,
    synopsis,
    releaseYear,
    runtime,
    genre,
    language,
    director,
    "poster": poster.asset->url,
    "thumbVideo": thumbVideo.asset->url,
    trailerUrl,
    screenerUrl,
    access,
    awardsCount,
    festivals,
    featured,
    "order": order
  }
`;

export const filmBySlugQuery = groq`
  *[_type == "film" && slug.current == $slug][0] {
    _id, title, "slug": slug.current, tagline, synopsis,
    releaseYear, runtime, genre, language, director,
    "poster": poster.asset->url,
    "still": still.asset->url,
    "thumbVideo": thumbVideo.asset->url,
    trailerUrl, screenerUrl, access,
    "stills": stills[].asset->url,
    crew[]{ role, name },
    awards[]{ festival, prize, year, country },
    festivals[]{ name, year, country, selection },
    directorsNote,
    pressQuotes[]{ quote, source }
  }
`;

export const featuredFilmsQuery = groq`
  *[_type == "film" && featured == true] | order(order asc)[0...3] {
    _id, title, "slug": slug.current, tagline,
    "poster": poster.asset->url,
    "thumbVideo": thumbVideo.asset->url,
    releaseYear, genre
  }
`;

/* ────────────────  AWARDS  ──────────────── */

export const awardsQuery = groq`
  *[_type == "award"] | order(year desc, festival asc) {
    _id, festival, prize, year, country,
    "film": film->title,
    "filmSlug": film->slug.current
  }
`;

/* ────────────────  PRESS  ──────────────── */

export const pressQuery = groq`
  *[_type == "pressItem"] | order(publishedAt desc) {
    _id, headline, outlet, publishedAt, url, excerpt,
    "logo": outletLogo.asset->url
  }
`;

/* ────────────────  SERVICES  ──────────────── */

export const servicesQuery = groq`
  *[_type == "service"] | order(order asc) {
    _id, title, summary, deliverables, startingPrice, order
  }
`;

/* ────────────────  SITE SETTINGS  ──────────────── */

export const siteSettingsQuery = groq`
  *[_type == "siteSettings"][0] {
    siteName, tagline, description,
    "logo": logo.asset->url,
    "ogDefault": ogDefault.asset->url,
    contactEmail, contactPhone,
    socials[]{ platform, url },
    awardsCount, selectionsCount, countriesCount
  }
`;

/* ────────────────  TYPES  ──────────────── */

export interface Film {
  _id: string;
  title: string;
  slug: string;
  tagline?: string;
  synopsis?: string;
  releaseYear?: number;
  runtime?: string;
  genre?: string[];
  language?: string;
  director?: string;
  poster?: string;
  still?: string;
  thumbVideo?: string;
  trailerUrl?: string;
  screenerUrl?: string;
  access?: 'free' | 'screener' | 'unreleased';
  awardsCount?: number;
  festivals?: { name: string; year: number; country: string; selection: string }[];
  featured?: boolean;
  order?: number;
  stills?: string[];
  crew?: { role: string; name: string }[];
  awards?: { festival: string; prize: string; year: number; country: string }[];
  directorsNote?: string;
  pressQuotes?: { quote: string; source: string }[];
}

export interface SiteSettings {
  siteName: string;
  tagline: string;
  description: string;
  logo?: string;
  ogDefault?: string;
  contactEmail: string;
  contactPhone?: string;
  socials: { platform: string; url: string }[];
  awardsCount: number;
  selectionsCount: number;
  countriesCount: number;
}
