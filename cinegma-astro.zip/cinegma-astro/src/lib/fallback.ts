/**
 * Fallback content — mirrors the films already on cinegmafilms.com
 * so the site renders perfectly even before Sanity is connected.
 * Once SANITY_PROJECT_ID is set in .env, this file is bypassed.
 */
import type { Film, SiteSettings } from './queries';

export const FALLBACK_SITE: SiteSettings = {
  siteName: 'Cinegma Films',
  tagline: 'Independent Pakistani cinema',
  description:
    'Cinegma Films is the independent production banner of Pakistani filmmaker Syed Asad Raza Abidi — director, editor, colorist and founder based in Karachi.',
  contactEmail: 'info@cinegmafilms.com',
  socials: [
    { platform: 'instagram', url: 'https://www.instagram.com/asadsyed711' },
    { platform: 'imdb', url: 'https://www.imdb.com/name/nm16938510/' },
    { platform: 'filmfreeway', url: 'https://filmfreeway.com/SyedAsad' },
    { platform: 'youtube', url: 'https://youtube.com/@syedasad' },
    { platform: 'linkedin', url: 'https://www.linkedin.com/in/asadsyed711' },
  ],
  awardsCount: 14,
  selectionsCount: 22,
  countriesCount: 9,
};

export const FALLBACK_FILMS: Film[] = [
  {
    _id: 'janjaal',
    title: 'Janjaal',
    slug: 'janjaal',
    tagline: 'Tussle',
    synopsis:
      'A police officer discovers a cursed golden pocket watch. Each wish he makes exacts a deadly price — until the watch chooses him.',
    releaseYear: 2024,
    runtime: '23 min',
    genre: ['Thriller', 'Psychological Thriller'],
    language: 'Urdu',
    director: 'Syed Asad Raza Abidi',
    poster: 'https://cinegmafilms.com/assets/posters/Janjaal%20Watch%20Cover.avif',
    thumbVideo: 'https://cinegmafilms.com/assets/posters/Janjaal%20Cover%20Video.mp4',
    trailerUrl: 'https://CinegmaFilms.b-cdn.net/Janjaal%20-%20Official%20Trailer.mp4',
    screenerUrl: 'https://CinegmaFilms.b-cdn.net/Copy%20Of%20Janjaal%204K%2025Fps%205.1.mp4',
    access: 'screener',
    awardsCount: 14,
    featured: true,
    order: 1,
  },
  {
    _id: 'soldier',
    title: 'A Soldier Beside Me',
    slug: 'a-soldier-beside-me',
    synopsis:
      "Two soldiers question each other's fate on the frontline. A short film on loyalty, war, and humanity.",
    releaseYear: 2026,
    genre: ['War Drama'],
    director: 'Syed Asad Raza Abidi',
    poster: 'https://cinegmafilms.com/assets/posters/Soldier%20Watch%20Cover.avif',
    access: 'unreleased',
    featured: true,
    order: 2,
  },
  {
    _id: 'zawaal',
    title: 'Zawaal',
    slug: 'zawaal',
    synopsis:
      'At the hour of decline — a man confronts the choices that shaped the ruin of everything he built.',
    releaseYear: 2026,
    genre: ['Psychological Thriller'],
    director: 'Syed Asad Raza Abidi',
    poster: 'https://cinegmafilms.com/assets/posters/Zawaal%20Watch%20Cover.avif',
    access: 'unreleased',
    featured: true,
    order: 3,
  },
  {
    _id: 'portrait',
    title: 'Portrait of Life',
    slug: 'portrait-of-life',
    synopsis:
      'A painter struggles to capture his wife the way he once did — a meditation on love, memory, and the limits of art.',
    releaseYear: 2025,
    genre: ['Drama'],
    director: 'Syed Asad Raza Abidi',
    poster: 'https://cinegmafilms.com/assets/posters/Portrait%20of%20Life%20Watch%20Cover.avif',
    access: 'screener',
    order: 4,
  },
  {
    _id: 'payam',
    title: 'Payam e Dil',
    slug: 'payam-e-dil',
    synopsis:
      'A message of the heart — a quiet, tender story about what goes unsaid between people who were meant to reach each other.',
    releaseYear: 2026,
    genre: ['Drama'],
    language: 'Urdu',
    director: 'Faizan Ahmed',
    poster: 'https://cinegmafilms.com/assets/posters/Payam%20e%20DilWatch%20Cover.avif',
    access: 'unreleased',
    order: 5,
  },
  {
    _id: 'achu',
    title: 'Main Aur Achu',
    slug: 'main-aur-achu',
    synopsis:
      "A boy and his goat — a warm, honest story about sacrifice, love, and the weight of Eid ul Azha on a child's heart.",
    releaseYear: 2024,
    genre: ['Drama', 'Family'],
    language: 'Urdu',
    director: 'Syed Asad Raza Abidi',
    poster: 'https://cinegmafilms.com/assets/posters/Main%20Aur%20achu%20watch%20cover.avif',
    screenerUrl: 'https://CinegmaFilms.b-cdn.net/Main%20Aur%20Achu%20-%20A%20Short%20Film.mp4',
    access: 'free',
    order: 6,
  },
  {
    _id: 'urdu-bazaar',
    title: 'Urdu Bazaar Karachi',
    slug: 'urdu-bazaar-karachi',
    synopsis:
      "Inside the narrow lanes and bookshops of Karachi's historic literary market.",
    releaseYear: 2024,
    genre: ['Documentary'],
    language: 'Urdu',
    director: 'Syed Asad Raza Abidi',
    poster: 'https://cinegmafilms.com/assets/posters/URDU%20BAZAR%20COVER%20AVIF.avif',
    screenerUrl: 'https://CinegmaFilms.b-cdn.net/Urdu%20Bazaar%20-%20Documentary%20-%20Final%20Edit.mp4',
    access: 'free',
    order: 7,
  },
];

export const FALLBACK_AWARDS = [
  { festival: 'Toronto Fantasy/Sci-Fi Film Festival', prize: 'Best Short Film', year: 2026, country: 'Canada' },
  { festival: 'Cedar Film Festival', prize: 'Best Director', year: 2026, country: 'Lebanon' },
  { festival: 'Cedar Film Festival', prize: 'Best Film', year: 2026, country: 'Lebanon' },
  { festival: 'Gandhara International Film Festival', prize: 'Best Director', year: 2025, country: 'Pakistan' },
  { festival: 'KISFF India', prize: 'Best Director', year: 2025, country: 'India' },
  { festival: 'KISFF India', prize: 'Best Short Film', year: 2025, country: 'India' },
  { festival: 'PIFF', prize: 'Best Short Film', year: 2025, country: 'Pakistan' },
  { festival: 'TMFF Scotland', prize: 'Best Trailer', year: 2025, country: 'Scotland' },
  { festival: 'Indus IFF', prize: 'Best Director', year: 2025, country: 'Pakistan' },
];

export const FALLBACK_SERVICES = [
  {
    _id: 'direction',
    title: 'Direction',
    summary: 'Narrative shorts, branded films, music videos. End-to-end story shaping from script to lock.',
    deliverables: ['Treatment', 'Shot list', 'On-set direction', 'Director-approved cut'],
  },
  {
    _id: 'editing',
    title: 'Editing & Color',
    summary: 'DaVinci Resolve workflow. Long-form documentary, short film, and ad cuts with cinematic finishing.',
    deliverables: ['Offline edit', 'Conform', 'Color grade', 'Final mastered delivery'],
  },
  {
    _id: 'production',
    title: 'Production',
    summary: 'Full-service short film and commercial production based in Karachi. Crew, gear, locations.',
    deliverables: ['Budget', 'Schedule', 'Crew & cast', 'Delivery'],
  },
];
