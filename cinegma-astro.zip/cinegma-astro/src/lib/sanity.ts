import { createClient, type SanityClient } from '@sanity/client';
import imageUrlBuilder from '@sanity/image-url';
import type { SanityImageSource } from '@sanity/image-url/lib/types/types';

const projectId = import.meta.env.PUBLIC_SANITY_PROJECT_ID;
const dataset = import.meta.env.PUBLIC_SANITY_DATASET || 'production';
const token = import.meta.env.SANITY_API_READ_TOKEN;

if (!projectId) {
  console.warn('⚠️  PUBLIC_SANITY_PROJECT_ID is not set. Sanity queries will return empty data.');
}

export const sanity: SanityClient = createClient({
  projectId: projectId || 'placeholder',
  dataset,
  apiVersion: '2024-12-01',
  useCdn: true,
  perspective: 'published',
  token, // optional, only needed for drafts / private datasets
});

// For draft previews (preview mode)
export const sanityPreview: SanityClient = createClient({
  projectId: projectId || 'placeholder',
  dataset,
  apiVersion: '2024-12-01',
  useCdn: false,
  perspective: 'previewDrafts',
  token,
});

const builder = imageUrlBuilder(sanity);
export const urlFor = (source: SanityImageSource) => builder.image(source);

/**
 * Safe fetch wrapper — returns null on error instead of throwing,
 * so a missing CMS connection never breaks the build.
 */
export async function safeFetch<T>(query: string, params: Record<string, unknown> = {}): Promise<T | null> {
  if (!projectId) return null;
  try {
    return await sanity.fetch<T>(query, params);
  } catch (err) {
    console.error('Sanity fetch failed:', err);
    return null;
  }
}
