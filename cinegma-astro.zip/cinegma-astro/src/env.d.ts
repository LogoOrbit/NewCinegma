/// <reference path="../.astro/types.d.ts" />

interface ImportMetaEnv {
  readonly PUBLIC_SANITY_PROJECT_ID: string;
  readonly PUBLIC_SANITY_DATASET: string;
  readonly SANITY_API_READ_TOKEN: string;
  readonly RESEND_API_KEY: string;
  readonly RESEND_AUDIENCE_ID: string;
  readonly PUBLIC_PLAUSIBLE_DOMAIN: string;
  readonly PUBLIC_SITE_URL: string;
  readonly EPK_ALLOWED_DOMAINS: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
