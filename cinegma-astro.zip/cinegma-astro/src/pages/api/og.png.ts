import type { APIRoute } from 'astro';
import { ImageResponse } from '@vercel/og';

export const prerender = false;

export const GET: APIRoute = async ({ request }) => {
  const { searchParams } = new URL(request.url);
  const title = (searchParams.get('title') || 'Cinegma Films').slice(0, 80);
  const sub = (searchParams.get('sub') || 'Independent Pakistani Cinema').slice(0, 80);

  return new ImageResponse(
    {
      type: 'div',
      props: {
        style: {
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          background: '#080808',
          color: '#f0ece4',
          padding: '70px 80px',
          fontFamily: 'sans-serif',
        },
        children: [
          // Top brand bar
          {
            type: 'div',
            props: {
              style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 22, letterSpacing: '0.3em' },
              children: [
                { type: 'div', props: { children: 'CINEGMA' } },
                { type: 'div', props: { style: { color: '#c9a55a' }, children: '— FILMS' } },
              ],
            },
          },

          // Main title
          {
            type: 'div',
            props: {
              style: { display: 'flex', flexDirection: 'column', gap: 28 },
              children: [
                {
                  type: 'div',
                  props: {
                    style: { fontSize: 88, lineHeight: 1.05, letterSpacing: '-0.01em', maxWidth: 980 },
                    children: title,
                  },
                },
                {
                  type: 'div',
                  props: {
                    style: { fontSize: 32, color: 'rgba(240,236,228,0.7)', fontStyle: 'italic' },
                    children: sub,
                  },
                },
              ],
            },
          },

          // Footer line
          {
            type: 'div',
            props: {
              style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 20, letterSpacing: '0.2em', color: 'rgba(240,236,228,0.55)' },
              children: [
                { type: 'div', props: { children: '14 AWARDS · 9 COUNTRIES' } },
                { type: 'div', props: { children: 'CINEGMAFILMS.COM' } },
              ],
            },
          },

          // Gold accent line
          {
            type: 'div',
            props: {
              style: { position: 'absolute', top: 0, left: 0, height: 4, width: 200, background: '#c9a55a' },
            },
          },
        ],
      },
    } as any,
    {
      width: 1200,
      height: 630,
      headers: {
        'Cache-Control': 'public, immutable, no-transform, max-age=31536000',
      },
    },
  );
};
