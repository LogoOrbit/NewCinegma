import type { APIRoute } from 'astro';
import { Resend } from 'resend';

export const prerender = false;

const RESEND_API_KEY = import.meta.env.RESEND_API_KEY;
const TO_EMAIL = 'info@cinegmafilms.com';
const FROM_EMAIL = 'Cinegma Films <noreply@cinegmafilms.com>'; // domain must be verified in Resend

const isEmail = (s: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);

export const POST: APIRoute = async ({ request }) => {
  try {
    const body = await request.json();
    const name = String(body.name || '').trim().slice(0, 200);
    const email = String(body.email || '').trim().slice(0, 200);
    const subject = String(body.subject || '').trim().slice(0, 200) || 'Inquiry via cinegmafilms.com';
    const message = String(body.message || '').trim().slice(0, 4000);

    // Simple validation + honeypot guard
    if (!name || !email || !message) {
      return Response.json({ error: 'Please fill name, email, and message.' }, { status: 400 });
    }
    if (!isEmail(email)) {
      return Response.json({ error: 'Please use a valid email.' }, { status: 400 });
    }

    if (!RESEND_API_KEY) {
      console.warn('Resend not configured. Logging contact submission:', { name, email, subject, message });
      return Response.json({ message: 'Message received (preview mode).' });
    }

    const resend = new Resend(RESEND_API_KEY);
    await resend.emails.send({
      from: FROM_EMAIL,
      to: TO_EMAIL,
      replyTo: email,
      subject: `[Cinegma.com] ${subject}`,
      text:
`Name:    ${name}
Email:   ${email}
Subject: ${subject}

${message}
`,
    });

    return Response.json({ message: 'Thank you. I will reply soon.' });
  } catch (err) {
    console.error('Contact error:', err);
    return Response.json({ error: 'Could not send. Try again or email info@cinegmafilms.com directly.' }, { status: 500 });
  }
};
