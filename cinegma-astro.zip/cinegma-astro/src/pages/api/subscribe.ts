import type { APIRoute } from 'astro';
import { Resend } from 'resend';

export const prerender = false;

const RESEND_API_KEY = import.meta.env.RESEND_API_KEY;
const AUDIENCE_ID = import.meta.env.RESEND_AUDIENCE_ID;

const isEmail = (s: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);

export const POST: APIRoute = async ({ request }) => {
  try {
    const { email } = await request.json();
    if (!email || !isEmail(email)) {
      return Response.json({ error: 'Please enter a valid email.' }, { status: 400 });
    }
    if (!RESEND_API_KEY || !AUDIENCE_ID) {
      console.warn('Resend not configured. Stub-saving email:', email);
      return Response.json({ message: 'Subscribed (preview mode).' });
    }
    const resend = new Resend(RESEND_API_KEY);
    await resend.contacts.create({
      email,
      audienceId: AUDIENCE_ID,
      unsubscribed: false,
    });
    return Response.json({ message: 'You are in. Welcome to Cinegma.' });
  } catch (err) {
    console.error('Subscribe error:', err);
    return Response.json({ error: 'Could not subscribe. Try again later.' }, { status: 500 });
  }
};
