import rss from '@astrojs/rss';
import type { APIRoute } from 'astro';
import { FALLBACK_FILMS } from '@lib/fallback';
import { safeFetch } from '@lib/sanity';
import { allFilmsQuery, type Film } from '@lib/queries';

export const GET: APIRoute = async (context) => {
  const films = (await safeFetch<Film[]>(allFilmsQuery)) ?? FALLBACK_FILMS;

  return rss({
    title: 'Cinegma Films',
    description: 'Independent Pakistani cinema by Syed Asad Raza Abidi.',
    site: context.site || 'https://cinegmafilms.com',
    items: films.map((f) => ({
      title: f.title + (f.tagline ? ` (${f.tagline})` : ''),
      description: f.synopsis || '',
      link: `/films/${f.slug}`,
      pubDate: new Date(`${f.releaseYear || 2024}-01-01`),
      categories: f.genre,
    })),
    customData: '<language>en-pk</language>',
  });
};
